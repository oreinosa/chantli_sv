export interface Workplace {
  id?: string;
  name?: string;
}
export class Workplace {
  constructor(public id?: string, public name?: string) { }
}
