export interface ClassWithName {
  className?: string;
}
export class ClassWithName {
  constructor(public className?: string) { }
}