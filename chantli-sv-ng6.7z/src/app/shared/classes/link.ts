export interface Link {
  label?: string;
  route?: string;
  icon?: string;
}
