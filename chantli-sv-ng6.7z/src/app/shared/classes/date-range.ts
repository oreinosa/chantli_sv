export interface DateRange {
  from?: Date;
  to?: Date;
}
