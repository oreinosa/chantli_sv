import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-step-4',
  templateUrl: './step-4.component.html',
  styleUrls: ['./step-4.component.css']
})
export class Step4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
