export class Notification {
  constructor(
    public title?: string,
    public body?: string,
    public background?: string,
    public icon?: string
  ) { }
}
