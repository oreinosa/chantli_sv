import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-del-user',
  templateUrl: './del-user.component.html',
  styleUrls: ['./del-user.component.css']
})
export class DelUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}